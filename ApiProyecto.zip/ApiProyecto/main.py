from tokenize import String
from typing import Optional
from unittest import result
from PredictionModel import Model
import pandas as pd
from XDataModel import XDataModel
import FuntionTransformer

from fastapi import FastAPI


app = FastAPI()


@app.get("/")
def read_root():
    #Aquideberiamos poner pagina de inicio, No se como funciona :()
    return {"Hello": "World"}


@app.get("/items/{item_id}")
def read_item(item_id: int, q: Optional[str] = None):
    return {"item_id": item_id, "q": q}




@app.post("/predict")
def load_abstract(data_model: XDataModel ):
    df = pd.DataFrame(data_model.dict(), columns=data_model.dict().keys(), index=[0])
    model = Model(data_model.columns())
    return (model.make_predictions(df))
    

@app.post("/metricas")
def metricas(dataModel):
    data = []
    for i in dataModel:
        data.append(i.dict())
    df = pd.json_normalize(data)
    model = Model(['medical_abstracts', 'problems_described'])
    y = df['problems_described']
    x = df['medical_abstracts']
    result = model.dar_Metrica(x,y)
    return result
