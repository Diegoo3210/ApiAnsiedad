from joblib import load
#from  myfunctions import Tokenizer, FunctionTransformerOnFeature, ColumnSelector, DataRetriever
from FunctionTransformerOnFeature import FunctionTransformerOnFeature


class Model:
    def __init__(self, columns):
        self.model = load("modelo.pkl")
    
    def make_predictions(self, data):
        result = self.model.predict(data)
        return result

    def dar_Metrica(self, x, y):
        return self.model.score(x,y)
