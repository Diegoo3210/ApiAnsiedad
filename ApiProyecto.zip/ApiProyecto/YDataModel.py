from pydantic import BaseModel


class YDataModel(BaseModel):
    medical_abstracts: str
    problems_described: int

    def columns(self):
        return ['medical_abstracts', 'problems_described']