import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin

class FunctionTransformerOnFeature(BaseEstimator,TransformerMixin):
    def __init__(self, func, feature_name):
        self.func = func
        self.feature_name = feature_name

    def fit(self, X, y=None):
        return self

    def transform(self,X,y=None):
        X = pd.DataFrame(X).copy()
        X[self.feature_name] = X[self.feature_name].apply(self.func)
        return X
