from setuptools import find_packages, setup
setup(
    name='AllLibraries',
    packages=find_packages(),
    version='0.1.0',
    description='My first Python library',
    install_requires=['pandas', 'sklearn','nltk' ],
    author='Me',
    license='MIT',
)