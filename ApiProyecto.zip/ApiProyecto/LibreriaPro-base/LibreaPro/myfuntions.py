import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin, ClassifierMixin
from nltk import word_tokenize

class Tokenizer(BaseEstimator,TransformerMixin):
    def __init__(self):
        pass

    def fit(self,X,y=None):
        return self
    
    def transform(self,X,y=None):
        X = pd.DataFrame(X).copy()
        X['words'] = X['medical_abstracts'].apply(word_tokenize)
        return X

# Se crea un transformador personalizado para ejecutar funciones sobre columnas específicas
class FunctionTransformerOnFeature(BaseEstimator,TransformerMixin):
    def __init__(self, func, feature_name):
        self.func = func
        self.feature_name = feature_name

    def fit(self, X, y=None):
        return self

    def transform(self,X,y=None):
        X = pd.DataFrame(X).copy()
        X[self.feature_name] = X[self.feature_name].apply(self.func)
        return X


# Se crea una clase que recupere los datos transformados por el pipeline
class ColumnSelector(BaseEstimator, TransformerMixin):
    def __init__(self,feature_name):
        self.feature_name = feature_name

    def fit(self, X, y=None):
        return self
    
    def transform(self, X, y=None):
        return X[self.feature_name]

# Se crea una clase que recupere los datos transformados por el pipeline
class DataRetriever(BaseEstimator, TransformerMixin):
    def __init__(self):
        pass

    def fit(self, X, y=None):
        self.values = pd.DataFrame.sparse.from_spmatrix(X)
        return self
    
    def transform(self, X, y=None):
        X= pd.DataFrame.sparse.from_spmatrix(X)
        return X.to_numpy()
