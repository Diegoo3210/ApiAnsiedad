from pydantic import BaseModel


class XDataModel(BaseModel):
    medical_abstracts: str

    def columns(self):
        return ['medical_abstracts']

